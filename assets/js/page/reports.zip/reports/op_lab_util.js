/* /assets/js/page/reports/op_lab_util.js */
$(function () {
  // --- Setup: Date range + helpers
  const $drp = $("#f_daterange");
  const supportsDRP = !!$.fn.daterangepicker;
  if (supportsDRP) {
    $drp.daterangepicker({
      autoUpdateInput: true,
      startDate: moment().subtract(6, "days"),
      endDate: moment(),
      locale: { format: "YYYY-MM-DD" },
    });
  } else {
    $drp.val(
      moment().subtract(6, "days").format("YYYY-MM-DD") +
        " - " +
        moment().format("YYYY-MM-DD")
    );
  }
  function parseRange(s) {
    const p = (s || "").split(" - ");
    return { from: p[0] || "", to: p[1] || "" };
  }

  // --- Category select (Choices/Select2 if present) – DISABLED
  // const $cat = $("#f_category");
  // if (window.Choices) {
  //   new Choices("#f_category", {
  //     allowHTML: false,
  //     removeItemButton: true,
  //     searchPlaceholderValue: "Search category",
  //   });
  // } else if ($.fn.select2) {
  //   $cat.select2({
  //     placeholder: "All categories",
  //     allowClear: true,
  //     width: "100%",
  //   });
  // }

  // --- DataTable
  const $table = $("#utilTable");
  const dt = $table.DataTable({
    serverSide: false,
    paging: true,
    searching: true,
    ordering: true,
    columns: [
      { data: "test_name" },
      // { data: "category", render: (c) => c || "—" }, // category column disabled
      { data: "orders", className: "text-end" },
    ],
    order: [[1, "desc"]], // was [2,"desc"] when category existed
    data: [],
    language: { emptyTable: "Use filters and click Apply to see results" },
  });

  // --- Column visibility toggles
  $(".col-toggle").on("change", function () {
    const idx = parseInt(this.value, 10);
    dt.column(idx).visible(this.checked);
  });

  // --- Quick ranges
  $(".quick-range").on("click", function () {
    const key = $(this).data("range");
    let from = moment(),
      to = moment();
    if (key === "7d") from = moment().subtract(6, "days");
    else if (key === "30d") from = moment().subtract(29, "days");
    else if (key === "qtd") from = moment().startOf("quarter");
    else if (key === "ytd") from = moment().startOf("year");
    if (supportsDRP) $drp.data("daterangepicker").setStartDate(from);
    if (supportsDRP) $drp.data("daterangepicker").setEndDate(to);
    $drp.val(from.format("YYYY-MM-DD") + " - " + to.format("YYYY-MM-DD"));
  });

  // --- AJAX function
  function getLabTests() {
    const { from, to } = parseRange($drp.val());
    $.ajax({
      url: "ajax/opReports/op_lab_util_list.php",
      type: "post",
      dataType: "json",
      data: {
        from: from,
        to: to,
        // category: $("#f_category").val(), // disabled
        doctor: $("#f_doctor").val(),
        test_search: $("#f_test_search").val(),
      },
      success: function (data) {
        console.log("Raw:", data);
        console.table(data);
        dt.clear().rows.add(data).draw();
        toggleEmpty(data.length === 0);
      },
      error: function (err) {
        console.log(err);
        dt.clear().draw();
        toggleEmpty(true);
      },
    });
  }

  // --- Apply
  $("#btnApply").on("click", function () {
    getLabTests();
  });

  // --- Export (placeholder)
  $("#btnExport").on("click", function () {
    toastr && toastr.info
      ? toastr.info("Export endpoint not connected yet.")
      : alert("Export endpoint not connected yet.");
  });

  // --- Saved view
  $("#btnSaveView").on("click", function () {
    const name = ($("#f_view_name").val() || "").trim();
    if (!name)
      return toastr && toastr.warning
        ? toastr.warning("Enter a view name")
        : alert("Enter a view name");
    const view = {
      range: $drp.val(),
      // category: $("#f_category").val(), // disabled
      doctor: $("#f_doctor").val(),
      testq: $("#f_test_search").val(),
    };
    localStorage.setItem("opLabUtilView:" + name, JSON.stringify(view));
    toastr && toastr.success ? toastr.success("Saved") : alert("Saved");
  });

  // --- Reset
  $("#btnReset").on("click", function () {
    if (supportsDRP) {
      $drp.data("daterangepicker").setStartDate(moment().subtract(6, "days"));
      $drp.data("daterangepicker").setEndDate(moment());
    }
    $drp.val(
      moment().subtract(6, "days").format("YYYY-MM-DD") +
        " - " +
        moment().format("YYYY-MM-DD")
    );
    // $("#f_category").val(""); // disabled
    // if ($cat.data("select2")) $cat.val(null).trigger("change");
    $("#f_doctor").val("");
    $("#f_test_search").val("");
    dt.clear().draw();
    toggleEmpty(true);
  });

  // --- Empty state
  function toggleEmpty(isEmpty) {
    $("#emptyState").toggleClass("d-none", !isEmpty);
    $(".table-responsive").toggleClass("d-none", isEmpty);
  }
  toggleEmpty(true);
});
