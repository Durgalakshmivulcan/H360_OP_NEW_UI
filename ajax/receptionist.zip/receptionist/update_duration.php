<?php

require_once("../../config/functions.php");

// Read incoming POST parameters
$appointmentId = $_POST['appointment_id'];
$action        = isset($_POST['action']) ? trim($_POST['action']) : '';
$now           = date('Y-m-d H:i:s');

header('Content-Type: application/json');
// Accept start, done and lapsed actions. If an unknown action is provided, return an error.
if (!$appointmentId || !in_array($action, ['start', 'done', 'lapsed'])) {
    echo json_encode(['status' => 'error', 'message' => 'Invalid parameters']);
    exit;
}

try {
    if ($action === 'start') {
        // Insert a new duration record with check_in time
        $stmt = $conn->prepare("INSERT INTO doctor_patient_duration (appointment_id, check_in) VALUES (?, ?)");
        $stmt->bind_param("ss", $appointmentId, $now);
        $stmt->execute();
        $stmt->close();
        // Update visitor_status to 2 (in session)
        $conn->query("UPDATE appointment_online SET visitor_status = '2' WHERE appoint_register_id = '$appointmentId'");
        echo json_encode(['status' => 'ok', 'message' => 'Check-in recorded']);
    } elseif ($action === 'done') {
        // Attempt to close the most recent open session; if none exists, visitor_status is still set to done
        $stmt = $conn->prepare("UPDATE doctor_patient_duration SET check_out = ? WHERE appointment_id = ? AND check_out IS NULL ORDER BY id DESC LIMIT 1");
        $stmt->bind_param("ss", $now, $appointmentId);
        $stmt->execute();
        $stmt->close();
        // Always update visitor_status to 0 (completed)
        $conn->query("UPDATE appointment_online SET visitor_status = '0' WHERE appoint_register_id = '$appointmentId'");
        echo json_encode(['status' => 'ok', 'message' => 'Visit marked as completed']);
    } elseif ($action === 'lapsed') {
        // Mark appointment as no-show (lapsed) regardless of current state
        $conn->query("UPDATE appointment_online SET visitor_status = '3' WHERE appoint_register_id = '$appointmentId'");
        echo json_encode(['status' => 'ok', 'message' => 'Patient marked as lapsed']);
    }
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
?>