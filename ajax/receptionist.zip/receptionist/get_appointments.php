<?php
/*
 * This script returns a JSON array of upcoming/outstanding appointments for
 * the receptionist dashboard.  It joins the appointments table with
 * doctors and services to display human‑readable names and also sums
 * the total time a patient has spent in the doctor's room so far based
 * on the `doctor_patient_duration` table.  You can extend the query to
 * filter by date, doctor or service using additional POST parameters.
 */

require_once("../../config/functions.php");

header('Content-Type: application/json');
$SessionUserId = $_SESSION['security_id'];
    $SessionRoleId = $_SESSION['role_id'];
    $SessionOrgId = $_SESSION['org_id'];
// Optional filters
$fromDate = isset($_POST['fromDate']) && $_POST['fromDate'] !== '' ? $_POST['fromDate'] : date('Y-m-d');
$toDate   = isset($_POST['toDate']) && $_POST['toDate'] !== '' ? $_POST['toDate'] : date('Y-m-d');
$doctorId = isset($_POST['doctor']) && $_POST['doctor'] !== '' ? (int) $_POST['doctor'] : null;
$serviceId= isset($_POST['service']) && $_POST['service'] !== '' ? (int) $_POST['service'] : null;

$where   = [];
$where[] = "DATE(a.appoint_date) BETWEEN '".$fromDate."' AND '".$toDate."'";
if ($doctorId) {
    // Filter appointments for a specific doctor id
    $where[] = "d.doc_id = " . $doctorId;
}
if ($serviceId) {
    // filter appointments whose doctor offers the selected service
    $where[] = "FIND_IN_SET(".$serviceId.", d.doctor_services) > 0";
}

$whereClause = implode(' AND ', $where);

// Query appointments with doctor and service names; compute total duration
// Build query: use appoint_date for appointment date and start_time/end_time for time range.
// appoint_unicode is treated as the patient identifier; patient_name holds the patient's name.
$sql = "SELECT a.appoint_register_id, a.appoint_unicode, a.patient_name, a.appoint_date, a.start_time, a.end_time,"
     . " d.doctor_name, s.service_name, a.appoint_status, a.visitor_status, a.valid_from, a.valid_to,"
     . " IFNULL(SUM(TIMESTAMPDIFF(MINUTE, dpd.check_in, dpd.check_out)), 0) AS minutes_spent,"
     . " COUNT(CASE WHEN dpd.check_out IS NULL THEN 1 END) AS open_sessions"
     . " FROM appointment_online a"
     . " JOIN doctors d ON a.doctor_name = d.doc_id"
     . " JOIN services s ON FIND_IN_SET(s.service_id, d.doctor_services) > 0"
     . " LEFT JOIN doctor_patient_duration dpd ON a.appoint_register_id = dpd.appointment_id"
     . " WHERE a.org_id ='$SessionOrgId' AND $whereClause"
     . " GROUP BY a.appoint_register_id, s.service_name";

$result = $conn->query($sql);
$appointments = [];
while ($row = $result->fetch_assoc()) {
    // Determine human readable status using visitor_status codes.
    // 1 = pending (waiting to be called), 2 = start (in the doctor's room),
    // 0 = done/completed, 3 = lapse (no‑show).
    $statusText = '';
    switch ($row['visitor_status']) {
        case '1': $statusText = 'Pending'; break;
        case '2': $statusText = 'Active'; break;
        case '0': $statusText = 'Done'; break;
        case '3': $statusText = 'No Show'; break;
        default:  $statusText = 'Pending';
    }
    $appointments[] = [
        'appoint_register_id'     => $row['appoint_register_id'],
        'patient_id'     => $row['appoint_unicode'],
        'patient_name'   => $row['patient_name'],
        'doctor_name'    => $row['doctor_name'],
        'service_name'   => $row['service_name'],
        'appoint_date'   => $row['appoint_date'],
        'start_time'     => $row['start_time'],
        'end_time'       => $row['end_time'],
        'status'         => $statusText,
        'visitor_status' => $row['visitor_status'],
        'valid_from'     => $row['valid_from'],
        'valid_to'       => $row['valid_to'],
        'minutes_spent'  => $row['minutes_spent'],
        'open_sessions'  => $row['open_sessions'],
    ];
}

echo json_encode($appointments);
?>